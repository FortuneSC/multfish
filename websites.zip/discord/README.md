# Discord Login Form

## Author: [KasRoudra](https://github.com/KasRoudra)

#### This is created for educational purposes demonstrating how phishung works.

### Use/Copy it legally and provide proper credit